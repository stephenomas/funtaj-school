<div class="vertical-menu">

                <div data-simplebar class="h-100">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            <li class="menu-title">Menu</li>

                            <li>
                                <a href="./" class="waves-effect">
                                    <i class="ri-dashboard-line"></i><span class="badge rounded-pill bg-success float-end">3</span>
                                    <span>Dashboard</span>
                                </a>
                            </li>

                            <li>
                                <a href="calendar" class=" waves-effect">
                                    <i class="ri-calendar-2-line"></i>
                                    <span>Calendar</span>
                                </a>
                            </li>

                            <li>
                                <a href="comment-bank" class=" waves-effect">
                                    <i class="ri-chat-1-line"></i>
                                    <span>Comment Bank</span>
                                </a>
                            </li>

                            
                
                            <li>
                                <a href="javascript: void(0);" class="has-arrow waves-effect">
                                    <i class="ri-mail-send-line"></i>
                                    <span>School Options</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    <li><a href="school-info">School Info</a></li>
                                    <li><a href="terms-session">Terms & Sessions</a></li>
                                    <li><a href="subjects">Subjects</a></li>
                                    <li><a href="classes">Classes</a></li>
                                    <li><a href="signatures">Upload Signatures</a></li>
                                </ul>
                            </li>

                            <li>
                                <a href="staffs" class=" waves-effect">
                                    <i class="ri-group-line"></i>
                                    <span>Staffs</span>
                                </a>
                            </li>
                            <li>
                                <a href="students" class=" waves-effect">
                                    <i class="ri-team-line"></i>
                                    <span>Students</span>
                                </a>
                            </li>


                            <li class="menu-title">Finance</li>

                            <li>
                                <a href="javascript: void(0);" class="has-arrow waves-effect">
                                    <i class="ri-store-2-line"></i>
                                    <span>Store</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    <li><a href="products">Products</a></li>
                                    <li><a href="orders">Orders</a></li>
                                    <!-- <li><a href="javascript: void(0);">Customers</a></li> -->
                                    <li><a href="cart">Cart</a></li>
                                    <li><a href="checkout">Checkout</a></li>
                                    <li><a href="shops">Shops</a></li>
                                    <li><a href="add=product">Add Product</a></li>
                                </ul>
                            </li>

                            <li>
                                <a href="javascript: void(0);" class="has-arrow waves-effect">
                                    <i class="ri-account-circle-line"></i>
                                    <span>Fees</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    <li><a href="school-fees">School Fees</a></li>
                                    <li><a href="expenditure">Expenditure</a></li>
                                    <!-- <li><a href="javascript: void(0);">Recover Password</a></li>
                                    <li><a href="javascript: void(0);">Lock Screen</a></li> -->
                                </ul>
                            </li>

                            <li class="menu-title">School</li>


                            <li>
                                <a href="notes" class=" waves-effect">
                                    <i class="ri-book-3-line"></i>
                                    <span>Notes</span>
                                </a>
                            </li>

                            <li>
                                <a href="assignments" class=" waves-effect">
                                    <i class="ri-todo-line"></i>
                                    <span>Assignments</span>
                                </a>
                            </li>

                            <li>
                                <a href="avascript: void(0);" class=" waves-effect">
                                    <i class="ri-article-line"></i>
                                    <span>Reports</span>
                                </a>
                            </li>

                            <li>
                                <a href="avascript: void(0);" class=" waves-effect">
                                    <i class="ri-message-3-line"></i>
                                    <span>Comments Bank</span>
                                </a>
                            </li>

                            <li>
                                <a href="javascript: void(0);" class="waves-effect">
                                    <i class="ri-map-pin-line"></i>
                                    <span>Branches</span>
                                </a>
                            </li>


                        </ul>
                    </div>
                    <!-- Sidebar -->
                </div>
            </div>